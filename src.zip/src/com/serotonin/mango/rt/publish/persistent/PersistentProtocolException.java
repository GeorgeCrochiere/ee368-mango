package com.serotonin.mango.rt.publish.persistent;

public class PersistentProtocolException extends Exception {
    private static final long serialVersionUID = 5178593744483624380L;

    public PersistentProtocolException(String message) {
        super(message);
    }
}
